function nutthue(){
    /** đổi id là body đổi lại BG của nó */
    document.getElementById("box").style.display="flex";
   
    document.getElementById("box2").style.display="none";
  }
  function nutmua(){
    /** đổi id là body đổi lại BG của nó */
    document.getElementById("box2").style.display="flex";
    
    document.getElementById("box").style.display="none";
  }
